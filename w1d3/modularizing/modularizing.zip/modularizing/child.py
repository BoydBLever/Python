import parent #all of code from parent.py executes on the import statement.
print(locals()) #prints namespace, the accessible variables, functions and classes during execution
#To open directory, Terminal command, 'open .' then press enter. This opens folders in a new tab